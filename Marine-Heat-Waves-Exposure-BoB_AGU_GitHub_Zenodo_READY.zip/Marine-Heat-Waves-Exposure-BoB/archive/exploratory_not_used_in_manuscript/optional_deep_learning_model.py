#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Optional Deep Learning Model

Refined for GitHub + Zenodo release supporting the manuscript:
"An Emerging Marine Heatwave Exposure Regime in the Bay of Bengal:
Stratification-Mediated Persistence and Compound Heat-Oxygen Risk".

Notes
-----
- This file was converted from the author's original Google Colab-exported notebook.
- Colab-only shell commands, Google Drive mount calls, and personal Drive paths were
  removed or replaced with repository-relative path variables.
- Configure data locations through environment variables or by editing DATA_ROOT below.
- Large raw NOAA/Copernicus files should not be committed to GitHub; archive processed
  and figure-ready data in Zenodo as described in docs/source_data_access.md.
"""

from __future__ import annotations

import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1] if "scripts" in Path(__file__).parts else Path(__file__).resolve().parents[2]
DATA_ROOT = Path(os.environ.get("MHW_DATA_ROOT", PROJECT_ROOT / "data"))
OUTPUT_ROOT = Path(os.environ.get("MHW_OUTPUT_ROOT", PROJECT_ROOT / "outputs"))
for _p in (DATA_ROOT, OUTPUT_ROOT):
    _p.mkdir(parents=True, exist_ok=True)



# %% [markdown]
# # **LSTM Model**


# %% Cell 2
# ============================================================
# BAY OF BENGAL MHW DEEP LEARNING MODEL
# Q1-suitable supplementary predictive experiment
# Input: 3-day composite persistence metrics CSV
# Tasks:
#   (1) Classification: predict is_mhw_bin
#   (2) Regression: predict mhw_frac
# Designed for Google Colab (~12 GB RAM)
# ============================================================

# -------------------------
# 1) Install dependencies
# -------------------------
# Colab shell command removed for repository reproducibility: !pip -q install tensorflow pandas numpy scikit-learn matplotlib openpyxl

# -------------------------
# 2) Imports
# -------------------------
import os
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    roc_auc_score, accuracy_score, f1_score, precision_score, recall_score,
    confusion_matrix, mean_squared_error, mean_absolute_error, r2_score
)

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

warnings.filterwarnings("ignore")
np.random.seed(42)
tf.random.set_seed(42)

# -------------------------
# 3) Mount Google Drive
# -------------------------
# Google Colab Drive import removed; use config/paths_template.yaml and local data folders.
# Google Drive mount removed; configure DATA_ROOT in this script or via environment variable MHW_DATA_ROOT.


# %% Cell 3
# -------------------------
# 4) USER SETTINGS
# -------------------------
INPUT_CSV = str(DATA_ROOT / "Marine Heat Waves Dataset (2000-24)/BoB_upper_ocean_persistence Outputs 1D & 3D/1D_outputs Final/BoB_upper_ocean_daily_metrics_1D.csv")

OUTDIR = str(DATA_ROOT / "BoB_DL_outputs")
os.makedirs(OUTDIR, exist_ok=True)

SEQ_LEN = 10          # 10 x 3-day composites ~ 30-day context
BATCH_SIZE = 32
EPOCHS = 80
LEARNING_RATE = 1e-3
DPI = 2400

# Choose predictor set
FEATURE_COLS = [
    "N2_shallow",
    "N2_deep",
    "MLD",
    "month_sin",
    "month_cos"
]

TARGET_CLASS = "is_mhw_bin"
TARGET_REG = "mhw_frac"

# Time split fractions
TRAIN_FRAC = 0.70
VAL_FRAC   = 0.15
TEST_FRAC  = 0.15

# -------------------------
# 5) Plot style
# -------------------------
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
    "font.size": 11,
    "axes.titlesize": 14,
    "axes.labelsize": 12,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "legend.fontsize": 10,
    "axes.linewidth": 0.8
})

# -------------------------
# 6) Helper functions
# -------------------------
def savefig2400(fig, path_png, path_pdf=None):
    fig.savefig(path_png, dpi=DPI, bbox_inches="tight", facecolor="white")
    if path_pdf is not None:
        fig.savefig(path_pdf, bbox_inches="tight", facecolor="white")

def add_calendar_features(df, date_col="bin_start"):
    df = df.copy()
    dt = pd.to_datetime(df[date_col])
    month = dt.dt.month
    df["month_sin"] = np.sin(2 * np.pi * month / 12.0)
    df["month_cos"] = np.cos(2 * np.pi * month / 12.0)
    return df

def make_sequences(df, feature_cols, target_col, seq_len=10):
    X, y, t = [], [], []
    vals = df[feature_cols].values
    targ = df[target_col].values
    times = pd.to_datetime(df["bin_start"]).values

    for i in range(seq_len, len(df)):
        X.append(vals[i-seq_len:i, :])
        y.append(targ[i])
        t.append(times[i])

    return np.array(X, dtype=np.float32), np.array(y), np.array(t)

def chronological_split(X, y, t, train_frac=0.7, val_frac=0.15):
    n = len(X)
    n_train = int(n * train_frac)
    n_val = int(n * val_frac)

    X_train = X[:n_train]
    y_train = y[:n_train]
    t_train = t[:n_train]

    X_val = X[n_train:n_train+n_val]
    y_val = y[n_train:n_train+n_val]
    t_val = t[n_train:n_train+n_val]

    X_test = X[n_train+n_val:]
    y_test = y[n_train+n_val:]
    t_test = t[n_train+n_val:]

    return X_train, y_train, t_train, X_val, y_val, t_val, X_test, y_test, t_test

def scale_3d_sequences(X_train, X_val, X_test):
    n_train, seq_len, n_feat = X_train.shape
    scaler = StandardScaler()

    X_train_2d = X_train.reshape(-1, n_feat)
    X_val_2d = X_val.reshape(-1, n_feat)
    X_test_2d = X_test.reshape(-1, n_feat)

    X_train_scaled = scaler.fit_transform(X_train_2d).reshape(X_train.shape)
    X_val_scaled = scaler.transform(X_val_2d).reshape(X_val.shape)
    X_test_scaled = scaler.transform(X_test_2d).reshape(X_test.shape)

    return X_train_scaled, X_val_scaled, X_test_scaled, scaler

def build_lstm_classifier(input_shape, lr=1e-3):
    model = keras.Sequential([
        layers.Input(shape=input_shape),
        layers.Masking(mask_value=0.0),
        layers.LSTM(32, return_sequences=False, dropout=0.2, recurrent_dropout=0.0),
        layers.Dense(16, activation="relu"),
        layers.Dropout(0.2),
        layers.Dense(1, activation="sigmoid")
    ])

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=lr),
        loss="binary_crossentropy",
        metrics=[
            keras.metrics.AUC(name="auc"),
            keras.metrics.BinaryAccuracy(name="accuracy")
        ]
    )
    return model

def build_lstm_regressor(input_shape, lr=1e-3):
    model = keras.Sequential([
        layers.Input(shape=input_shape),
        layers.Masking(mask_value=0.0),
        layers.LSTM(32, return_sequences=False, dropout=0.2, recurrent_dropout=0.0),
        layers.Dense(16, activation="relu"),
        layers.Dropout(0.2),
        layers.Dense(1, activation="linear")
    ])

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=lr),
        loss="mse",
        metrics=[keras.metrics.MeanAbsoluteError(name="mae")]
    )
    return model

def classification_report_dict(y_true, y_prob, threshold=0.5):
    y_pred = (y_prob >= threshold).astype(int)
    return {
        "AUC": roc_auc_score(y_true, y_prob) if len(np.unique(y_true)) > 1 else np.nan,
        "Accuracy": accuracy_score(y_true, y_pred),
        "F1": f1_score(y_true, y_pred, zero_division=0),
        "Precision": precision_score(y_true, y_pred, zero_division=0),
        "Recall": recall_score(y_true, y_pred, zero_division=0)
    }

def regression_report_dict(y_true, y_pred):
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    return {
        "RMSE": rmse,
        "MAE": mean_absolute_error(y_true, y_pred),
        "R2": r2_score(y_true, y_pred)
    }


# %% Cell 4
df = pd.read_csv(INPUT_CSV)
print(df.columns.tolist())


# %% Cell 5
# -------------------------
# 7) Load and prepare data
# -------------------------
df = pd.read_csv(INPUT_CSV)
df = df.rename(columns={"date": "bin_start"}) # Renaming 'date' column to 'bin_start'
df = df.rename(columns={"is_mhw": "is_mhw_bin"}) # Renaming 'is_mhw' to 'is_mhw_bin'
df["bin_start"] = pd.to_datetime(df["bin_start"])
df = df.sort_values("bin_start").reset_index(drop=True)

# --- Start of added code ---
# Temporary fix: Assign mhw_frac to is_mhw_bin if mhw_frac is missing
# This allows the regression model to run, but assumes mhw_frac is binary (0 or 1)
# If mhw_frac is intended to be a continuous value, this line should be adjusted
# to calculate it correctly or ensure it's present in the input CSV.
if "mhw_frac" not in df.columns:
    print("Warning: 'mhw_frac' column not found. Assigning 'is_mhw_bin' as a placeholder.")
    df["mhw_frac"] = df["is_mhw_bin"].astype(float)
# --- End of added code ---

required_cols = ["bin_start", "N2_shallow", "N2_deep", "MLD", "mhw_frac", "is_mhw_bin"]
missing = [c for c in required_cols if c not in df.columns]
if missing:
    raise ValueError(f"Missing required columns in input CSV: {missing}")

df = add_calendar_features(df, "bin_start")

# Keep only complete rows
df = df.dropna(subset=["N2_shallow", "N2_deep", "MLD", "mhw_frac", "is_mhw_bin"]).copy()
df["is_mhw_bin"] = df["is_mhw_bin"].astype(int)

print("Prepared rows:", len(df))
print(df.head())


# %% Cell 6
# -------------------------
# 8) Classification dataset
# -------------------------
# Ensure calendar features are present, in case of kernel state inconsistencies
if "month_sin" not in df.columns or "month_cos" not in df.columns:
    df = add_calendar_features(df, "bin_start")

X_cls, y_cls, t_cls = make_sequences(df, FEATURE_COLS, TARGET_CLASS, seq_len=SEQ_LEN)

Xc_train, yc_train, tc_train, Xc_val, yc_val, tc_val, Xc_test, yc_test, tc_test = chronological_split(
    X_cls, y_cls, t_cls, train_frac=TRAIN_FRAC, val_frac=VAL_FRAC
)

Xc_train, Xc_val, Xc_test, scaler_cls = scale_3d_sequences(Xc_train, Xc_val, Xc_test)

print("Classification shapes:")
print(Xc_train.shape, Xc_val.shape, Xc_test.shape)

# -------------------------
# 9) Regression dataset
# -------------------------
# Ensure calendar features are present, in case of kernel state inconsistencies
if "month_sin" not in df.columns or "month_cos" not in df.columns:
    df = add_calendar_features(df, "bin_start")

X_reg, y_reg, t_reg = make_sequences(df, FEATURE_COLS, TARGET_REG, seq_len=SEQ_LEN)

Xr_train, yr_train, tr_train, Xr_val, yr_val, tr_val, Xr_test, yr_test, tr_test = chronological_split(
    X_reg, y_reg, t_reg, train_frac=TRAIN_FRAC, val_frac=VAL_FRAC
)

Xr_train, Xr_val, Xr_test, scaler_reg = scale_3d_sequences(Xr_train, Xr_val, Xr_test)

print("Regression shapes:")
print(Xr_train.shape, Xr_val.shape, Xr_test.shape)

# -------------------------
# 10) Train classifier
# -------------------------
classifier = build_lstm_classifier(input_shape=(Xc_train.shape[1], Xc_train.shape[2]), lr=LEARNING_RATE)

callbacks = [
    keras.callbacks.EarlyStopping(monitor="val_loss", patience=10, restore_best_weights=True),
    keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=5, min_lr=1e-5)
]

history_cls = classifier.fit(
    Xc_train, yc_train,
    validation_data=(Xc_val, yc_val),
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    verbose=1,
    callbacks=callbacks
)

# -------------------------
# 11) Evaluate classifier
# -------------------------
yc_prob = classifier.predict(Xc_test, verbose=0).ravel()
cls_metrics = classification_report_dict(yc_test, yc_prob, threshold=0.5)
cls_df = pd.DataFrame([cls_metrics])
cls_df.to_csv(os.path.join(OUTDIR, "DL_classification_metrics.csv"), index=False)

print("\nClassification metrics:")
print(cls_df)

# -------------------------
# 12) Train regressor
# -------------------------
regressor = build_lstm_regressor(input_shape=(Xr_train.shape[1], Xr_train.shape[2]), lr=LEARNING_RATE)

history_reg = regressor.fit(
    Xr_train, yr_train,
    validation_data=(Xr_val, yr_val),
    epochs=EPOCHS,
    batch_size=BATCH_SIZE,
    verbose=1,
    callbacks=callbacks
)

# -------------------------
# 13) Evaluate regressor
# -------------------------
yr_pred = regressor.predict(Xr_test, verbose=0).ravel()
reg_metrics = regression_report_dict(yr_test, yr_pred)
reg_df = pd.DataFrame([reg_metrics])
reg_df.to_csv(os.path.join(OUTDIR, "DL_regression_metrics.csv"), index=False)

print("\nRegression metrics:")
print(reg_df)

# -------------------------
# 14) Save predictions
# -------------------------
pred_cls = pd.DataFrame({
    "bin_start": pd.to_datetime(tc_test),
    "y_true": yc_test,
    "y_prob": yc_prob,
    "y_pred": (yc_prob >= 0.5).astype(int)
})
pred_cls.to_csv(os.path.join(OUTDIR, "DL_classification_predictions.csv"), index=False)

pred_reg = pd.DataFrame({
    "bin_start": pd.to_datetime(tr_test),
    "y_true": yr_test,
    "y_pred": yr_pred
})
pred_reg.to_csv(os.path.join(OUTDIR, "DL_regression_predictions.csv"), index=False)

# -------------------------
# 15) 2400 dpi figure
# -------------------------
fig, axes = plt.subplots(1, 3, figsize=(17.2, 5.4), constrained_layout=False)

# (a) classifier training
ax = axes[0]
ax.plot(history_cls.history["loss"], label="Train loss", linewidth=1.4)
ax.plot(history_cls.history["val_loss"], label="Validation loss", linewidth=1.4)
ax.set_title("(a) LSTM classification training")
ax.set_xlabel("Epoch")
ax.set_ylabel("Binary cross-entropy")
ax.legend(frameon=False)

# (b) classifier ROC-style summary text + confusion-like scatter
ax = axes[1]
ax.scatter(
    pred_cls["y_prob"],
    np.random.normal(loc=pred_cls["y_true"], scale=0.02, size=len(pred_cls)),
    s=16, alpha=0.55
)
ax.axvline(0.5, color="black", linestyle="--", linewidth=1.0)
ax.set_xlim(0, 1)
ax.set_ylim(-0.15, 1.15)
ax.set_yticks([0, 1])
ax.set_yticklabels(["Non-MHW", "MHW"])
ax.set_xlabel("Predicted probability of MHW")
ax.set_ylabel("Observed class")
ax.set_title("(b) LSTM classification performance")
ax.text(
    0.03, 0.97,
    f"AUC = {cls_metrics['AUC']:.3f}\n"
    f"Accuracy = {cls_metrics['Accuracy']:.3f}\n"
    f"F1 = {cls_metrics['F1']:.3f}\n"
    f"Precision = {cls_metrics['Precision']:.3f}\n"
    f"Recall = {cls_metrics['Recall']:.3f}",
    transform=ax.transAxes, va="top", ha="left", fontsize=9
)

# (c) regression observed vs predicted
ax = axes[2]
ax.scatter(yr_test, yr_pred, s=20, alpha=0.65)
xymin = min(np.nanmin(yr_test), np.nanmin(yr_pred))
xymax = max(np.nanmax(yr_test), np.nanmax(yr_pred))
ax.plot([xymin, xymax], [xymin, xymax], color="black", linestyle="--", linewidth=1.0)
ax.set_xlabel("Observed MHW exposure fraction")
ax.set_ylabel("Predicted MHW exposure fraction")
ax.set_title("(c) LSTM regression performance")
ax.text(
    0.03, 0.97,
    f"R² = {reg_metrics['R2']:.3f}\n"
    f"RMSE = {reg_metrics['RMSE']:.3f}\n"
    f"MAE = {reg_metrics['MAE']:.3f}",
    transform=ax.transAxes, va="top", ha="left", fontsize=9
)

for ax in axes:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(True, linestyle=":", linewidth=0.45, alpha=0.4)

fig.suptitle(
    "Deep-learning prediction of Bay of Bengal marine heatwave persistence from upper-ocean diagnostics",
    fontsize=15, fontweight="bold", y=0.98
)
fig.subplots_adjust(left=0.07, right=0.985, bottom=0.14, top=0.84, wspace=0.28)

savefig2400(
    fig,
    os.path.join(OUTDIR, "DL_MHW_prediction_summary_2400dpi.png"),
    os.path.join(OUTDIR, "DL_MHW_prediction_summary_2400dpi.tiff"),
    os.path.join(OUTDIR, "DL_MHW_prediction_summary.pdf")
)
plt.show()
plt.close(fig)

# -------------------------
# 16) Save models
# -------------------------
classifier.save(os.path.join(OUTDIR, "LSTM_classifier.keras"))
regressor.save(os.path.join(OUTDIR, "LSTM_regressor.keras"))

# -------------------------
# 17) Console summary
# -------------------------
print("\nSaved files:")
for fn in sorted(os.listdir(OUTDIR)):
    print(os.path.join(OUTDIR, fn))

print("\nSuggested manuscript interpretation:")
print(
    "This deep-learning analysis should be presented as a supplementary predictive experiment. "
    "The process-based N²/MLD diagnostics remain the primary mechanistic evidence, while the LSTM tests "
    "whether short-horizon MHW occurrence and exposure can be predicted from recent upper-ocean persistence conditions."
)


# %% [markdown]
# # **small 1D CNN + BiLSTM hybrid Model**


# %% Cell 8
# ============================================================
# BAY OF BENGAL UPPER-OCEAN PERSISTENCE METRICS
# DEEP LEARNING DAILY (1D) VERSION | 1995-2024
# Q1-style workflow using prepared daily metrics CSV
#
# PURPOSE
#   (a) Shallow N² anomaly during high-exposure years
#   (b) Deep-learning probability scaling of daily MHW occurrence
#   (c) Daily MLD contrast between MHW and non-MHW days
#
# INPUT
#   Prepared daily metrics CSV from your 1D workflow
#
# OUTPUT
#   - Excel workbook + CSV tables
#   - 2400 dpi PNG with panels A, B, C only
#
# MODEL
#   Compact Conv1D + BiLSTM classifier
#
# NOTE
#   For publication, use this as a predictive robustness model.
#   Keep inferential statistics as the primary main-text result.
# ============================================================

# -------------------------
# 1) Install dependencies
# -------------------------
# Colab shell command removed for repository reproducibility: !pip -q install pandas numpy matplotlib scipy scikit-learn openpyxl tensorflow

# -------------------------
# 2) Imports
# -------------------------
import os
import re
import random
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from scipy.stats import ttest_ind
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    roc_auc_score, average_precision_score, brier_score_loss,
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix
)

import tensorflow as tf
from tensorflow.keras import layers, models, callbacks, optimizers

warnings.filterwarnings("ignore")

# -------------------------
# 3) Mount Google Drive
# -------------------------
# Google Colab Drive import removed; use config/paths_template.yaml and local data folders.
# Google Drive mount removed; configure DATA_ROOT in this script or via environment variable MHW_DATA_ROOT.

# -------------------------
# 4) USER SETTINGS
# -------------------------
# Use your prepared 1D daily metrics CSV as input
INPUT_CSV = str(DATA_ROOT / "Marine Heat Waves Dataset (2000-24)/BoB_upper_ocean_persistence Outputs 1D & 3D/1D_outputs Final/BoB_upper_ocean_daily_metrics_1D.csv")

OUTDIR = str(DATA_ROOT / "BoB_upper_ocean_DL_outputs_1D")
os.makedirs(OUTDIR, exist_ok=True)

OUT_WORKBOOK_XLSX = os.path.join(OUTDIR, "BoB_upper_ocean_DL_outputs_1D.xlsx")
OUT_DAILY_CSV     = os.path.join(OUTDIR, "BoB_upper_ocean_daily_metrics_with_DL_1D.csv")
OUT_ANNUAL_CSV    = os.path.join(OUTDIR, "BoB_upper_ocean_annual_metrics_with_DL_1D.csv")
OUT_SUMMARY_CSV   = os.path.join(OUTDIR, "BoB_upper_ocean_DL_summary_1D.csv")
OUT_PANELB_CSV    = os.path.join(OUTDIR, "BoB_upper_ocean_DL_panelB_curve_1D.csv")
OUT_TESTPRED_CSV  = os.path.join(OUTDIR, "BoB_upper_ocean_DL_test_predictions_1D.csv")
OUT_HISTORY_CSV   = os.path.join(OUTDIR, "BoB_upper_ocean_DL_training_history_1D.csv")
OUT_SEASONAL_CSV  = os.path.join(OUTDIR, "BoB_upper_ocean_DL_seasonal_MLD_1D.csv") # Added this line
OUT_FIG_PNG       = os.path.join(OUTDIR, "BoB_upper_ocean_persistence_DL_summary_1D_2400dpi.png")

DPI = 2400
RANDOM_SEED = 42

# Rolling window length for sequence model
WINDOW = 14   # 14-day context window

# Temporal split
TRAIN_END = "2016-12-31"
VAL_END   = "2020-12-31"
TEST_END  = "2024-12-31"

# Panel A settings
HIGH_EXPOSURE_QUANTILE = 0.75
N_BOOT = 5000

# -------------------------
# 5) Reproducibility
# -------------------------
np.random.seed(RANDOM_SEED)
random.seed(RANDOM_SEED)
tf.random.set_seed(RANDOM_SEED)

# -------------------------
# 6) Plot style
# -------------------------
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
    "font.size": 11,
    "axes.titlesize": 15,
    "axes.labelsize": 12,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "legend.fontsize": 10,
    "axes.linewidth": 0.8,
    "xtick.major.width": 0.8,
    "ytick.major.width": 0.8,
    "xtick.direction": "out",
    "ytick.direction": "out",
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "savefig.facecolor": "white",
    "savefig.edgecolor": "white"
})


# %% Cell 9
# -------------------------
# 7) Helper functions
# -------------------------
def clean_columns(df):
    new_cols = []
    for c in df.columns:
        c = str(c).strip()
        c = re.sub(r"\s+", "_", c)
        new_cols.append(c)
    df.columns = new_cols
    return df

def detect_date_column(df):
    candidates = ["date", "bin_start", "time", "datetime", "Date", "DATE"]
    for c in candidates:
        if c in df.columns:
            return c
    for c in df.columns:
        cl = c.lower()
        if "date" in cl or "time" in cl:
            return c
    raise KeyError(f"No date-like column found. Available columns: {df.columns.tolist()}")

def add_calendar_features(df, date_col):
    df = df.copy()
    dt = pd.to_datetime(df[date_col])
    df["year"] = dt.dt.year
    df["month"] = dt.dt.month
    df["dayofyear"] = dt.dt.dayofyear
    df["weekday"] = dt.dt.weekday

    df["month_sin"] = np.sin(2 * np.pi * df["month"] / 12.0)
    df["month_cos"] = np.cos(2 * np.pi * df["month"] / 12.0)
    df["doy_sin"]   = np.sin(2 * np.pi * df["dayofyear"] / 366.0)
    df["doy_cos"]   = np.cos(2 * np.pi * df["dayofyear"] / 366.0)
    df["wday_sin"]  = np.sin(2 * np.pi * df["weekday"] / 7.0)
    df["wday_cos"]  = np.cos(2 * np.pi * df["weekday"] / 7.0)

    def season_from_month(m):
        if m in [12, 1, 2]:
            return "Winter"
        elif m in [3, 4, 5]:
            return "Pre-monsoon"
        elif m in [6, 7, 8, 9]:
            return "Monsoon"
        else:
            return "Post-monsoon"

    df["season"] = df["month"].apply(season_from_month)
    return df

def season_zscore(series, season):
    out = pd.Series(np.nan, index=series.index, dtype=float)
    for s in ["Winter", "Pre-monsoon", "Monsoon", "Post-monsoon"]:
        mask = season == s
        vals = pd.to_numeric(series.loc[mask], errors="coerce")
        mu = vals.mean()
        sd = vals.std(ddof=0)
        if np.isfinite(sd) and sd > 0:
            out.loc[mask] = (vals - mu) / sd
    return out

def bootstrap_mean_diff(a, b, n_boot=5000, seed=42):
    rng = np.random.default_rng(seed)
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    a = a[np.isfinite(a)]
    b = b[np.isfinite(b)]

    if len(a) < 10 or len(b) < 10:
        return np.nan, np.nan, np.nan, np.nan

    obs = np.mean(a) - np.mean(b)
    boots = np.empty(n_boot, dtype=float)

    for i in range(n_boot):
        aa = rng.choice(a, size=len(a), replace=True)
        bb = rng.choice(b, size=len(b), replace=True)
        boots[i] = np.mean(aa) - np.mean(bb)

    ci_low, ci_high = np.percentile(boots, [2.5, 97.5])
    _, pval = ttest_ind(a, b, equal_var=False, nan_policy="omit")
    return obs, ci_low, ci_high, pval

def regression_with_ci(x, y, alpha=0.05):
    import scipy.stats as stats
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]

    if len(x) < 8:
        return {
            "n": len(x), "slope": np.nan, "intercept": np.nan,
            "r2": np.nan, "p": np.nan,
            "slope_ci_low": np.nan, "slope_ci_high": np.nan
        }

    res = stats.linregress(x, y)
    dfree = len(x) - 2
    tcrit = stats.t.ppf(1 - alpha/2, dfree)

    return {
        "n": len(x),
        "slope": res.slope,
        "intercept": res.intercept,
        "r2": res.rvalue**2,
        "p": res.pvalue,
        "slope_ci_low": res.slope - tcrit * res.stderr,
        "slope_ci_high": res.slope + tcrit * res.stderr
    }

def make_sequences(df, feature_cols, target_col, window):
    X, y, dates, idxs = [], [], [], []
    arrX = df[feature_cols].values
    arrY = df[target_col].values
    arrD = pd.to_datetime(df["date"]).values

    for i in range(window - 1, len(df)):
        block = arrX[i - window + 1:i + 1]
        if np.all(np.isfinite(block)) and np.isfinite(arrY[i]):
            X.append(block)
            y.append(arrY[i])
            dates.append(arrD[i])
            idxs.append(i)

    X = np.asarray(X, dtype=np.float32)
    y = np.asarray(y, dtype=np.float32)
    dates = pd.to_datetime(np.asarray(dates))
    idxs = np.asarray(idxs, dtype=int)
    return X, y, dates, idxs

def build_dl_model(input_shape):
    model = models.Sequential([
        layers.Input(shape=input_shape),
        layers.Conv1D(filters=32, kernel_size=3, padding="same", activation="relu"),
        layers.BatchNormalization(),
        layers.Dropout(0.15),

        layers.Conv1D(filters=32, kernel_size=3, padding="same", activation="relu"),
        layers.MaxPooling1D(pool_size=2),
        layers.Dropout(0.15),

        layers.Bidirectional(layers.LSTM(32, return_sequences=False)),
        layers.Dropout(0.20),

        layers.Dense(32, activation="relu"),
        layers.Dropout(0.15),
        layers.Dense(1, activation="sigmoid")
    ])

    model.compile(
        optimizer=optimizers.Adam(learning_rate=1e-3),
        loss="binary_crossentropy",
        metrics=[
            tf.keras.metrics.AUC(name="auc"),
            tf.keras.metrics.AUC(name="pr_auc", curve="PR"),
            tf.keras.metrics.BinaryAccuracy(name="accuracy")
        ]
    )
    return model

def save_png(fig, outpath, dpi=2400):
    fig.patch.set_facecolor("white")
    for ax in fig.axes:
        ax.set_facecolor("white")
    fig.savefig(
        outpath,
        dpi=dpi,
        bbox_inches="tight",
        facecolor="white",
        edgecolor="white",
        transparent=False
    )

# -------------------------
# 8) Load and prepare data
# -------------------------
# Robust read for CSV/Excel
ext = os.path.splitext(INPUT_CSV)[1].lower()
if ext == ".csv":
    df = pd.read_csv(INPUT_CSV)
elif ext in [".xlsx", ".xls"]:
    df = pd.read_excel(INPUT_CSV)
else:
    raise ValueError(f"Unsupported input type: {ext}")

df = clean_columns(df)
date_col = detect_date_column(df)
df = df.rename(columns={date_col: "date"})
df["date"] = pd.to_datetime(df["date"], errors="coerce")
df = df.dropna(subset=["date"]).copy()
df = df.sort_values("date").reset_index(drop=True)

# Canonicalize expected columns
col_map = {}
for c in df.columns:
    cl = c.lower()
    if cl == "n2_shallow":
        col_map[c] = "N2_shallow"
    elif cl == "n2_deep":
        col_map[c] = "N2_deep"
    elif cl == "mld":
        col_map[c] = "MLD"
    elif cl == "is_mhw":
        col_map[c] = "is_mhw"

df = df.rename(columns=col_map)

required_cols = ["date", "N2_shallow", "N2_deep", "MLD", "is_mhw"]
missing = [c for c in required_cols if c not in df.columns]
if missing:
    raise ValueError(f"Missing required columns in input file: {missing}\nAvailable: {df.columns.tolist()}")

df = add_calendar_features(df, "date")
df = df.dropna(subset=["N2_shallow", "N2_deep", "MLD", "is_mhw"]).copy()
df["is_mhw"] = pd.to_numeric(df["is_mhw"], errors="coerce").fillna(0).astype(int)

print("Prepared rows:", len(df))
print(df.head())

# -------------------------
# 9) Annual metrics for panel A
# -------------------------
annual_df = (
    df.groupby("year", as_index=False)
      .agg(
          N2_shallow=("N2_shallow", "mean"),
          N2_deep=("N2_deep", "mean"),
          MLD=("MLD", "mean"),
          mhw_days=("is_mhw", "sum")
      )
)

threshold = annual_df["mhw_days"].quantile(HIGH_EXPOSURE_QUANTILE)
annual_df["high_exposure"] = annual_df["mhw_days"] >= threshold

high_vals = annual_df.loc[annual_df["high_exposure"], "N2_shallow"].values
other_vals = annual_df.loc[~annual_df["high_exposure"], "N2_shallow"].values

delta_n2, delta_n2_ci_low, delta_n2_ci_high, delta_n2_p = bootstrap_mean_diff(
    high_vals, other_vals, n_boot=N_BOOT, seed=RANDOM_SEED
)

reg_annual = regression_with_ci(
    annual_df["N2_shallow"].values,
    annual_df["mhw_days"].values
)

# -------------------------
# 10) Build DL features
# -------------------------
df["N2_shallow_z"] = season_zscore(df["N2_shallow"], df["season"])
df["N2_deep_z"]    = season_zscore(df["N2_deep"], df["season"])
df["MLD_z"]        = season_zscore(df["MLD"], df["season"])

feature_cols = [
    "N2_shallow_z",
    "N2_deep_z",
    "MLD_z",
    "month_sin", "month_cos",
    "doy_sin", "doy_cos",
    "wday_sin", "wday_cos"
]

df = df.dropna(subset=feature_cols).copy()

# -------------------------
# 11) Temporal split
# -------------------------
train_mask = df["date"] <= pd.Timestamp(TRAIN_END)
val_mask   = (df["date"] > pd.Timestamp(TRAIN_END)) & (df["date"] <= pd.Timestamp(VAL_END))
test_mask  = (df["date"] > pd.Timestamp(VAL_END)) & (df["date"] <= pd.Timestamp(TEST_END))

train_df = df.loc[train_mask].copy()
val_df   = df.loc[val_mask].copy()
test_df  = df.loc[test_mask].copy()

print("\nTemporal split sizes:")
print("Train:", len(train_df))
print("Val  :", len(val_df))
print("Test :", len(test_df))

# Scale only with train statistics
scaler = StandardScaler()
train_df.loc[:, feature_cols] = scaler.fit_transform(train_df[feature_cols])
val_df.loc[:, feature_cols]   = scaler.transform(val_df[feature_cols])
test_df.loc[:, feature_cols]  = scaler.transform(test_df[feature_cols])

# Reassemble in time order for sequence generation
df_scaled = pd.concat([train_df, val_df, test_df], axis=0).sort_values("date").reset_index(drop=True)

# -------------------------
# 12) Sequence generation
# -------------------------
X_all, y_all, seq_dates, seq_idxs = make_sequences(
    df_scaled, feature_cols, "is_mhw", WINDOW
)

seq_df = pd.DataFrame({
    "date": seq_dates,
    "row_idx": seq_idxs,
    "y_true": y_all
})

train_seq_mask = seq_df["date"] <= pd.Timestamp(TRAIN_END)
val_seq_mask   = (seq_df["date"] > pd.Timestamp(TRAIN_END)) & (seq_df["date"] <= pd.Timestamp(VAL_END))
test_seq_mask  = (seq_df["date"] > pd.Timestamp(VAL_END)) & (seq_df["date"] <= pd.Timestamp(TEST_END))

X_train, y_train = X_all[train_seq_mask.values], y_all[train_seq_mask.values]
X_val,   y_val   = X_all[val_seq_mask.values],   y_all[val_seq_mask.values]
X_test,  y_test  = X_all[test_seq_mask.values],  y_all[test_seq_mask.values]

seq_df_train = seq_df.loc[train_seq_mask].copy()
seq_df_val   = seq_df.loc[val_seq_mask].copy()
seq_df_test  = seq_df.loc[test_seq_mask].copy()

print("\nSequence shapes:")
print("X_train:", X_train.shape, "y_train:", y_train.shape)
print("X_val  :", X_val.shape,   "y_val  :", y_val.shape)
print("X_test :", X_test.shape,  "y_test :", y_test.shape)

# -------------------------
# 13) Class imbalance handling
# -------------------------
n_pos = max(int(np.sum(y_train == 1)), 1)
n_neg = max(int(np.sum(y_train == 0)), 1)
class_weight = {
    0: 1.0,
    1: n_neg / n_pos
}

print("\nClass weights:", class_weight)


# %% Cell 10
# -------------------------
# 14) Train deep learning model
# -------------------------
model = build_dl_model(input_shape=(X_train.shape[1], X_train.shape[2]))
model.summary()

cb = [
    callbacks.EarlyStopping(
        monitor="val_pr_auc",
        mode="max",
        patience=12,
        restore_best_weights=True,
        verbose=1
    ),
    callbacks.ReduceLROnPlateau(
        monitor="val_pr_auc",
        mode="max",
        factor=0.5,
        patience=5,
        min_lr=1e-5,
        verbose=1
    )
]

history = model.fit(
    X_train, y_train,
    validation_data=(X_val, y_val),
    epochs=80,
    batch_size=64,
    class_weight=class_weight,
    callbacks=cb,
    verbose=1
)

history_df = pd.DataFrame(history.history)

# -------------------------
# 15) Test predictions
# -------------------------
y_prob = model.predict(X_test, batch_size=256, verbose=0).ravel()
y_pred = (y_prob >= 0.5).astype(int)

auc = roc_auc_score(y_test, y_prob) if len(np.unique(y_test)) > 1 else np.nan
ap = average_precision_score(y_test, y_prob) if len(np.unique(y_test)) > 1 else np.nan
brier = brier_score_loss(y_test, y_prob)
acc = accuracy_score(y_test, y_pred)
prec = precision_score(y_test, y_pred, zero_division=0)
rec = recall_score(y_test, y_pred, zero_division=0)
f1 = f1_score(y_test, y_pred, zero_division=0)
tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel()

print("\nTest metrics:")
print("AUROC :", auc)
print("AUPRC :", ap)
print("Brier :", brier)
print("Acc   :", acc)
print("Prec  :", prec)
print("Recall:", rec)
print("F1    :", f1)

# Attach test predictions back to rows
test_pred_df = seq_df_test.copy()
test_pred_df["y_prob"] = y_prob
test_pred_df["y_pred"] = y_pred

# Bring N2/MLD context for figure/table
ctx = df_scaled.loc[:, ["date", "N2_shallow", "N2_deep", "MLD", "season", "year"]].copy()
test_pred_df = test_pred_df.merge(ctx, on="date", how="left")

# -------------------------
# 16) Panel B curve table
# -------------------------
# Use binned standardized shallow N² against observed and predicted MHW probability
panel_b_df = test_pred_df.copy()
panel_b_df["N2_shallow_std"] = season_zscore(panel_b_df["N2_shallow"], panel_b_df["season"])

panel_b_df = panel_b_df.dropna(subset=["N2_shallow_std", "y_true", "y_prob"]).copy()

# Equal-width bins
panel_b_df["x_bin"] = pd.cut(panel_b_df["N2_shallow_std"], bins=16)

panel_b_curve = (
    panel_b_df.groupby("x_bin", observed=False)
    .agg(
        x_center=("N2_shallow_std", "mean"),
        obs_prob=("y_true", "mean"),
        pred_prob=("y_prob", "mean"),
        n=("y_true", "size")
    )
    .reset_index(drop=True)
)

# -------------------------
# 17) Panel C daily MLD contrast
# -------------------------
mhw_mld = df.loc[(df["is_mhw"] == 1) & np.isfinite(df["MLD"]), "MLD"].values
non_mhw_mld = df.loc[(df["is_mhw"] == 0) & np.isfinite(df["MLD"]), "MLD"].values

panel_c_ok = (
    len(mhw_mld) >= 20 and
    len(non_mhw_mld) >= 20 and
    np.nanstd(mhw_mld) > 0 and
    np.nanstd(non_mhw_mld) > 0
)

if panel_c_ok:
    delta_mld, delta_mld_ci_low, delta_mld_ci_high, delta_mld_p = bootstrap_mean_diff(
        mhw_mld, non_mhw_mld, n_boot=N_BOOT, seed=RANDOM_SEED
    )
else:
    delta_mld, delta_mld_ci_low, delta_mld_ci_high, delta_mld_p = np.nan, np.nan, np.nan, np.nan

season_rows = []
for s in ["Winter", "Pre-monsoon", "Monsoon", "Post-monsoon"]:
    sub = df[df["season"] == s]
    a = sub.loc[(sub["is_mhw"] == 1) & np.isfinite(sub["MLD"]), "MLD"].values
    b = sub.loc[(sub["is_mhw"] == 0) & np.isfinite(sub["MLD"]), "MLD"].values
    if len(a) > 19 and len(b) > 19 and np.nanstd(a) > 0 and np.nanstd(b) > 0:
        d, lo, hi, p = bootstrap_mean_diff(a, b, n_boot=N_BOOT, seed=RANDOM_SEED)
        season_rows.append({
            "season": s,
            "delta_MLD": d,
            "ci_low": lo,
            "ci_high": hi,
            "p_value": p,
            "n_mhw_days": len(a),
            "n_nonmhw_days": len(b)
        })

seasonal_mld_df = pd.DataFrame(season_rows)


# %% Cell 11
# -------------------------
# 18) Summary table
# -------------------------
summary = pd.DataFrame([
    {
        "metric": "SHALLOW N2 ANOMALY DURING HIGH-EXPOSURE YEARS",
        "estimate": delta_n2,
        "ci_low": delta_n2_ci_low,
        "ci_high": delta_n2_ci_high,
        "p_value": delta_n2_p,
        "units": "s^-2"
    },
    {
        "metric": "DAILY MHW OCCURRENCE SCALING (Conv1D-BiLSTM, test AUROC)",
        "estimate": auc,
        "ci_low": np.nan,
        "ci_high": np.nan,
        "p_value": np.nan,
        "units": "AUROC"
    },
    {
        "metric": "DAILY MHW OCCURRENCE SCALING (Conv1D-BiLSTM, test AUPRC)",
        "estimate": ap,
        "ci_low": np.nan,
        "ci_high": np.nan,
        "p_value": np.nan,
        "units": "AUPRC"
    },
    {
        "metric": "DAILY MHW OCCURRENCE SCALING (Conv1D-BiLSTM, test Brier)",
        "estimate": brier,
        "ci_low": np.nan,
        "ci_high": np.nan,
        "p_value": np.nan,
        "units": "Brier score"
    },
    {
        "metric": "N2-MHW DAYS REGRESSION SLOPE (annual secondary)",
        "estimate": reg_annual["slope"],
        "ci_low": reg_annual["slope_ci_low"],
        "ci_high": reg_annual["slope_ci_high"],
        "p_value": reg_annual["p"],
        "units": "days per s^-2"
    },
    {
        "metric": "N2-MHW DAYS REGRESSION R2 (annual secondary)",
        "estimate": reg_annual["r2"],
        "ci_low": np.nan,
        "ci_high": np.nan,
        "p_value": np.nan,
        "units": "unitless"
    },
    {
        "metric": "MLD DIFFERENCE BETWEEN MHW AND NON-MHW DAILY WINDOWS",
        "estimate": delta_mld,
        "ci_low": delta_mld_ci_low,
        "ci_high": delta_mld_ci_high,
        "p_value": delta_mld_p,
        "units": "m"
    }
])

# -------------------------
# 19) Save Excel + CSV outputs
# -------------------------
df.to_csv(OUT_DAILY_CSV, index=False)
annual_df.to_csv(OUT_ANNUAL_CSV, index=False)
summary.to_csv(OUT_SUMMARY_CSV, index=False)
seasonal_mld_df.to_csv(OUT_SEASONAL_CSV, index=False)
panel_b_curve.to_csv(OUT_PANELB_CSV, index=False)
test_pred_df.to_csv(OUT_TESTPRED_CSV, index=False)
history_df.to_csv(OUT_HISTORY_CSV, index=False)

with pd.ExcelWriter(OUT_WORKBOOK_XLSX, engine="openpyxl") as writer:
    df.to_excel(writer, sheet_name="daily_metrics", index=False)
    annual_df.to_excel(writer, sheet_name="annual_metrics", index=False)
    summary.to_excel(writer, sheet_name="summary_metrics", index=False)
    seasonal_mld_df.to_excel(writer, sheet_name="seasonal_MLD", index=False)
    panel_b_curve.to_excel(writer, sheet_name="panelB_curve", index=False)
    test_pred_df.to_excel(writer, sheet_name="test_predictions", index=False)
    history_df.to_excel(writer, sheet_name="training_history", index=False)

# -------------------------
# 20) Figure: panels A, B, C only
# -------------------------
fig, axes = plt.subplots(1, 3, figsize=(17.8, 5.9), constrained_layout=False)
fig.patch.set_facecolor("white")

# Panel A
ax = axes[0]
ax.set_facecolor("white")
box = ax.boxplot(
    [high_vals, other_vals],
    tick_labels=["High-exposure\nyears", "Other\nyears"],
    patch_artist=True,
    widths=0.55,
    showfliers=False
)
for patch, color in zip(box["boxes"], ["#d95f02", "#1b9e77"]):
    patch.set_facecolor(color)
    patch.set_alpha(0.78)

ax.set_ylabel("Annual shallow N² (s$^{-2}$)")
ax.set_title("(a) Shallow N² anomaly")
ax.text(
    0.03, 0.97,
    f"ΔN² = {delta_n2:.2e}\n95% CI: {delta_n2_ci_low:.2e} to {delta_n2_ci_high:.2e}\np = {delta_n2_p:.3g}",
    transform=ax.transAxes, va="top", ha="left", fontsize=9
)

# Panel B
ax = axes[1]
ax.set_facecolor("white")

# Light test scatter
rng = np.random.default_rng(RANDOM_SEED)
plot_df = panel_b_df.copy()
if len(plot_df) > 4000:
    plot_df = plot_df.sample(4000, random_state=RANDOM_SEED)

y_jitter = plot_df["y_true"].values + rng.normal(0, 0.03, len(plot_df))
y_jitter = np.clip(y_jitter, -0.02, 1.02)

ax.scatter(
    plot_df["N2_shallow_std"].values,
    y_jitter,
    s=8,
    color="#2c7fb8",
    alpha=0.18,
    edgecolor="none",
    zorder=2
)

# Predicted probability curve
curve_ok = panel_b_curve["x_center"].notna().sum() >= 4
if curve_ok:
    curve_plot = panel_b_curve.dropna(subset=["x_center", "pred_prob"]).sort_values("x_center")
    ax.plot(
        curve_plot["x_center"].values,
        curve_plot["pred_prob"].values,
        color="#d95f0e",
        linewidth=2.2,
        zorder=3,
        label="DL predicted probability"
    )
    ax.plot(
        curve_plot["x_center"].values,
        curve_plot["obs_prob"].values,
        color="black",
        linewidth=1.2,
        linestyle="--",
        zorder=3,
        label="Observed binned probability"
    )

ax.text(
    0.03, 0.97,
    f"Conv1D-BiLSTM\nAUROC = {auc:.3f}\nAUPRC = {ap:.3f}\nBrier = {brier:.3f}\n"
    f"Precision = {prec:.3f}\nRecall = {rec:.3f}",
    transform=ax.transAxes, va="top", ha="left", fontsize=9
)

ax.set_xlabel("Season-standardized shallow N²")
ax.set_ylabel("Daily MHW occurrence probability")
ax.set_ylim(-0.02, 1.02)
ax.set_title("(b) Deep-learning MHW occurrence scaling")
ax.legend(frameon=False, loc="lower right")

# Panel C
ax = axes[2]
ax.set_facecolor("white")
if panel_c_ok:
    box = ax.boxplot(
        [mhw_mld, non_mhw_mld],
        tick_labels=["MHW\ndays", "Non-MHW\ndays"],
        patch_artist=True,
        widths=0.55,
        showfliers=False
    )
    for patch, color in zip(box["boxes"], ["#ef3b2c", "#6baed6"]):
        patch.set_facecolor(color)
        patch.set_alpha(0.78)

    rng = np.random.default_rng(RANDOM_SEED + 1)

    mhw_idx = np.arange(len(mhw_mld))
    non_idx = np.arange(len(non_mhw_mld))
    if len(mhw_idx) > 1200:
        mhw_idx = rng.choice(mhw_idx, size=1200, replace=False)
    if len(non_idx) > 1200:
        non_idx = rng.choice(non_idx, size=1200, replace=False)

    ax.scatter(
        np.ones(len(mhw_idx)) * 1 + rng.normal(0, 0.03, len(mhw_idx)),
        mhw_mld[mhw_idx],
        s=5, color="black", alpha=0.10, zorder=2
    )
    ax.scatter(
        np.ones(len(non_idx)) * 2 + rng.normal(0, 0.03, len(non_idx)),
        non_mhw_mld[non_idx],
        s=5, color="black", alpha=0.10, zorder=2
    )

    ax.text(
        0.03, 0.97,
        f"ΔMLD = {delta_mld:.2f} m\n95% CI: {delta_mld_ci_low:.2f} to {delta_mld_ci_high:.2f}\np = {delta_mld_p:.3g}",
        transform=ax.transAxes, va="top", ha="left", fontsize=9
    )

    y_all = np.concatenate([mhw_mld, non_mhw_mld])
    ypad = 0.08 * (np.nanmax(y_all) - np.nanmin(y_all) + 1e-6)
    ax.set_ylim(np.nanmin(y_all) - ypad, np.nanmax(y_all) + ypad)
else:
    ax.text(
        0.5, 0.5,
        "Insufficient finite\nMLD samples",
        transform=ax.transAxes, ha="center", va="center", fontsize=13
    )
    ax.set_xticks([1, 2])
    ax.set_xticklabels(["MHW\ndays", "Non-MHW\ndays"])

ax.set_ylabel("MLD (m)")
ax.set_title("(c) Daily MLD contrast")

for ax in axes:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(True, axis="y", linestyle=":", linewidth=0.45, alpha=0.45)

fig.suptitle(
    "Upper-ocean persistence diagnostics for Bay of Bengal marine heatwaves (1995–2024)",
    fontsize=16, fontweight="bold", y=0.98
)
fig.subplots_adjust(left=0.065, right=0.985, bottom=0.15, top=0.84, wspace=0.32)

save_png(fig, OUT_FIG_PNG)
plt.show()
plt.close(fig)

# -------------------------
# 21) Console summary
# -------------------------
print("\n================ FINAL METRICS ================\n")
print(summary.to_string(index=False))

print("\nSaved Excel workbook:")
print(OUT_WORKBOOK_XLSX)

print("\nSaved CSV files:")
print(OUT_DAILY_CSV)
print(OUT_ANNUAL_CSV)
print(OUT_SUMMARY_CSV)
print(OUT_SEASONAL_CSV)
print(OUT_PANELB_CSV)
print(OUT_TESTPRED_CSV)
print(OUT_HISTORY_CSV)

print("\nSaved figure:")
print(OUT_FIG_PNG)
